from .logger import Logger

from queue import Queue, Full, Empty
from threading import Thread, active_count
from typing import Callable, List
import traceback

from time import sleep

class Worker(Thread):
    """
    Thread executing tasks from a given tasks queue
    """
    def __init__(self, tasks: Queue, auto_resign: bool = False):
        """
        tasks: list of tasks for this worker
        auto_resign: resign when list of tasks done
        """
        super().__init__(daemon=True)
        self.__logger = Logger("THREAD")
        self.__tasks = tasks
        self.__executing = False
        self.__fired = False
        self.__auto_resign = auto_resign
        self.start()

    def assign(self, func: Callable, *args, **kwargs):
        """
        Assign new task to this worker

        Return: False if worker do too many tasks
        """
        if self.count() == self.__tasks.maxsize:
            return False
        
        try:
            self.__tasks.put_nowait((func, args, kwargs))
        except Full:
            return False
        return True
    
    def run(self):
        """
        Automatically execute task when employ. No need to call
        """
        while not self.__fired:
            try:
                func, args, kwargs = self.__tasks.get(timeout=1)
            except Empty:
                if self.__auto_resign:
                    self.resign()
                    break
                continue

            self.__executing = True
            try:
                func(*args, **kwargs)
            except Exception as e:
                if self.__logger:
                    self.__logger.error(f"[{func}({args}, {kwargs})] "
                                        f"Process died (Message: {e})\n"
                                        f"Traceback: {traceback.format_exc()}")
            self.__tasks.task_done()
            func, args, kwargs = (None, None, None)
            self.__executing = False

    def resign(self):
        """
        No need this worker anymore
        """
        self.__fired = True

    @staticmethod
    def employ(func: Callable):
        """
        (Decorator) Employ a worker for a function.
        Call function will make worker do the job in another thread.

        Return: Worker
        """
        def inner(*args, **kwargs):
            task_queue = Queue()
            task_queue.put((func, args, kwargs))
            worker = Worker(task_queue, True)
            return worker
        return inner
    
    def count(self):
        """
        Return number of tasks, including executing one
        """
        return self.__tasks.qsize() + self.__executing
    
    def useless(self):
        """
        True if worker do nothing
        """
        return self.count() == 0 and not self.__executing

    @staticmethod
    def threadCount():
        """
        Return number of active threads
        """
        return active_count()

class Manager:
    """
    Handle multiple workers
    """
    def __init__(self, worker_max_tasks: int = 7):
        """
        worker_max_tasks: max number of tasks of a worker
        """
        self.__fired = False
        self.__workers: List[Worker] = []
        self.__max_tasks = worker_max_tasks
        self.__autoFire()

    def addTask(self, func: Callable, *args, **kwargs):
        """
        Add task to a worker. Employ new one if others are busy.

        Return: Worker handles this task
        """
        for worker in self.__workers:
            if worker.assign(func, *args, **kwargs):
                return worker
        
        tasks = Queue(self.__max_tasks)
        tasks.put((func, args, kwargs))
        new_worker = Worker(tasks)
        self.__workers.append(new_worker)
        return new_worker
    
    def addJob(self, func: Callable, *args, **kwargs):
        """
        Assign one job to one worker and fire worker when job done
        """
        Worker.employ(func)(*args, **kwargs)
    
    @Worker.employ
    def __autoFire(self):
        """
        Remove no-task workers automatically
        """
        while not self.__fired:
            redundant_list = []
            for i in range(self.__workers.__len__()):
                if self.__workers[i].useless():
                    redundant_list.append(i)
            for i in redundant_list[::-1]:
                worker = self.__workers.pop(i)
                worker.resign()
                del worker
            sleep(3)

    def resign(self):
        """
        No need this manager anymore
        """
        self.__fired = True
    
    def count(self):
        """
        Return number of workers
        """
        return self.__workers.__len__()