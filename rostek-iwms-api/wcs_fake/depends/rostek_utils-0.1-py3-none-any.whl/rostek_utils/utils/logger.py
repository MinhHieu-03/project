from .pattern import SingleName
import logging

class ScreenFormatter(logging.Formatter):
    GREY = "\x1b[38;20m"
    BLUE = "\x1b[34;20m"
    YELLOW = "\x1b[33;20m"
    GREEN = "\x1b[32;20m"
    RED = "\x1b[31;20m"
    BOLD_RED = "\x1b[31;1m"
    BOLD = "\x1b[1m"
    RESET = "\x1b[0m"

    format = f"{GREEN}%(asctime)s{RESET} - "\
        f"{RESET}[%(pathname)s:%(lineno)d - in %(funcName)s] - [{RED}%(name)s: "\
        "{0}%(levelname)s"f"{RESET}] -> {BOLD}""{0}%(message)s"f"{RESET}"

    FORMATS = {
        logging.DEBUG: format.format(GREY),
        logging.INFO: format.format(BLUE),
        logging.WARNING: format.format(YELLOW),
        logging.ERROR: format.format(RED),
        logging.CRITICAL: format.format(BOLD_RED)
    }

    def format(self, record: logging.LogRecord):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)

class FileFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord):
        FORMAT = "\t[%(asctime)s] (%(pathname)s:%(lineno)d - func %(funcName)s) [%(name)s: %(levelname)s] -> %(message)s"
        return logging.Formatter(FORMAT).format(record)

class Logger(logging.Logger, metaclass=SingleName):
    """
    Create logger object for the first time to use
    """
    def __init__(self, name: str, level: str = 'info', to_screen: bool = True,
                 to_file: bool = False, file_name: str = None) -> None:
        """
        level: debug, info, warn, error, fatal
        file_name: required if to_file is True
        """
        super().__init__(name)
        lvl_text = ["debug", "info", "warn", "error", "fatal"]
        lvl_int = [logging.DEBUG, logging.INFO, logging.WARN, logging.ERROR, logging.FATAL]
        lvl_val = lvl_int[lvl_text.index(level)]

        if to_screen:
            h = logging.StreamHandler()
            h.setLevel(lvl_val)
            h.setFormatter(ScreenFormatter())
            self.addHandler(h)
        if to_file:
            h = logging.FileHandler(file_name)
            h.setLevel(lvl_val)
            h.setFormatter(FileFormatter())
            self.addHandler(h)
        if not to_screen and not to_file:
            self.disabled = True