import threading
from typing import Type, List, Dict

class Singleton(type):
    """
    Create a class which only init once
    Instruction:
        class foo(metaclass=Singleton)
    """
    _instance = {}
    _lock = threading.Lock()
    def __call__(cls, *args, **kwds):
        if cls not in cls._instance:
            with cls._lock:
                if cls not in cls._instance:
                    instance = super().__call__(*args, **kwds)
                    cls._instance[cls] = instance
        return cls._instance[cls]

class SingleName(type):
    """
    Create a class which only init once for each name
    Instruction:
        class foo(metaclass=SingleName)
    """
    _instance = {}
    _lock = threading.Lock()
    def __call__(cls, name: str, *args, **kwds):
        if name not in cls._instance:
            with cls._lock:
                if name not in cls._instance:
                    cls._instance[name] = super().__call__(name, *args, **kwds)
        return cls._instance[name]

from enum import Enum

class Custom_Enum(Enum):
    @classmethod
    def keys(cls) -> list:
        return cls._member_names_

    @classmethod
    def values(cls) -> list:
        return list(cls._value2member_map_.keys())

    @classmethod
    def list(cls) -> list:
        return list(cls)

    @classmethod
    def dict(cls) -> dict:
        return cls._member_map_

    @classmethod
    def index(cls, item: Type["Enum | str"]) -> int:
        """
        :item: can be member or name
        """
        if type(item) != str:
            item = item.name
        return cls._member_names_.index(item)

    @classmethod
    def get(cls, index: int):
        """
        Return value from index
        """
        return cls.values()[index]

import json

class Declare_Class:
    """
    Define all data properties.
    (No private properties listed)
    """
    @classmethod
    def keys(cls) -> list:
        """
        List all properties name
        """
        res = []
        for attr in cls.__annotations__:
            if not attr.startswith(f"_{cls.__name__}__"):
                res.append(attr)
        return res

    @classmethod
    def declaration(cls):
        """
        A dictionary of all properties name and type
        """
        res = {}
        for attr in cls.__annotations__:
            if not attr.startswith(f"_{cls.__name__}__"):
                res[attr] = cls.__annotations__[attr]
        return res
    
    @classmethod
    def defValues(cls):
        """
        Get a list of default values
        """
        res = []
        for attr in cls.__annotations__:
            if not attr.startswith(f"_{cls.__name__}__"):
                res.append(cls.__annotations__[attr]())
        return res
    
    @classmethod
    def defItems(cls):
        """
        Get a dictionary of default values
        """
        res = {}
        for attr in cls.__annotations__:
            if attr.startswith(f"_{cls.__name__}__"):
                continue

            res[attr] = cls.__parseValue(cls.__annotations__[attr], cls.__dict__.get(attr))
        return res
    
    @classmethod
    def fromDict(cls, data: dict):
        """
        Extract all properties from a dictionary

        * Undefined properties will be set default
        """
        obj = cls()
        for attr in cls.__annotations__:
            if attr.startswith(f"_{cls.__name__}__"):
                continue

            obj.__setattr__(attr, obj.__parseValue(obj.__annotations__[attr], data.get(attr)))
        return obj
    
    @classmethod
    def __parseValue(cls, type: Type["Declare_Class"], value = None):
        if value is not None:
            if type.__name__ == List.__name__:
                datas = []
                for data in value:
                    datas.append(cls.__parseValue(type.__args__[0], data))
                return datas
            elif type.__name__ == Dict.__name__:
                datas = {}
                for key in value:
                    datas[key] = cls.__parseValue(type.__args__[1], value[key])
                return datas
            elif type.__base__ == Declare_Class:
                return type.fromDict(value)
            else:
                return value
        else:
            if type.__name__ == List.__name__:
                return []
            elif type.__name__ == Dict.__name__:
                return {}
            else:
                return type()
    
    def __init__(self) -> None:
        items = type(self).defItems()
        for key in items:
            self.__setattr__(key, items[key])
    
    def values(self):
        """
        Get a list of all property values
        """
        res = []
        for attr in self.__annotations__:
            if not attr.startswith(f"_{self.__class__.__name__}__"):
                try:
                    res.append(self.__getattribute__(attr))
                except:
                    res.append(self.__annotations__[attr]())
        return res
    
    def items(self):
        """
        Get a dictionary of all {property: value}
        """
        res = {}
        for attr in self.__annotations__:
            if attr.startswith(f"_{self.__class__.__name__}__"):
                continue

            try:
                obj = self.__getattribute__(attr)
            except:
                obj = self.__annotations__[attr]()
            res[attr] = self.__parseItem(obj)
        return res
    
    def __parseItem(self, obj):
        if isinstance(obj, Declare_Class):
            return obj.items()
        elif isinstance(obj, list):
            datas = []
            for data in obj:
                datas.append(self.__parseItem(data))
            return datas
        elif isinstance(obj, dict):
            datas = {}
            for key in obj:
                datas[key] = self.__parseItem(obj[key])
            return datas
        else:
            return obj
    
    def set(self, data: dict):
        """
        Set some properties by dictionary. Raise exception if wrong properties name
        """
        for key in data:
            self.__setattr__(key, data[key])
    
    @classmethod
    def decode(cls, data: str):
        """
        Extract all properties from a json string

        * Undefined properties will be set default
        * Raise exception if json string is wrong
        """
        return cls.fromDict(json.loads(data))

    def encode(self) -> str:
        """
        Combine all properties to form a json string

        If some attributes are not defined, replaced by default values
        """
        return json.dumps(self.items())
    
class Define_Class(object):
    """
    Define all data properties
    """
    @classmethod
    def keys(cls):
        """
        List all properties name
        """
        res = []
        for attr in cls.__dict__:
            if not attr.startswith(f"_{cls.__name__}__") and not attr.startswith(f"__"):
                res.append(attr)
        return res
    
    @classmethod
    def values(cls):
        """
        Get a list of all values
        """
        res = []
        for attr in cls.__dict__:
            if not attr.startswith(f"_{cls.__name__}__") and not attr.startswith(f"__"):
                res.append(cls.__dict__[attr])
        return res
    
    @classmethod
    def items(cls):
        """
        Get a dictionary of all {property: value}
        """
        res = {}
        for attr in cls.__dict__:
            if not attr.startswith(f"_{cls.__name__}__") and not attr.startswith(f"__"):
                res[attr] = cls.__dict__[attr]
        return res

class Mapping_Class(Define_Class):
    """
    Provide mapping method between properties. Make sure to list all defined properties.
    """
    @staticmethod
    def mapping(src: List[Define_Class], des: List[Define_Class], *prop) -> List:
        data = []
        for p in prop:
            if p not in src:
                raise Exception(f"No '{p}' in {src}")
            data.append(des[src.index(p)])
        return data