from ..utils.logger import Logger
from ..utils.thread import Worker
from ..utils.pattern import Declare_Class
from .callback import Callback_Handle, CALLBACK_TYPE

import paho.mqtt.client as mqtt, json
from time import sleep
from typing import Callable, Type, Dict

class MQTT_CALLBACK_TYPE (CALLBACK_TYPE):
    CONNECT = "connect"
    RECEIVE = "receive"
    DISCONNECT = "disconnect"

class Mqtt_Message(Declare_Class):
    """
    Mqtt message abstract class. This class will not check properties' type.

    To define class value type. Examples:
        * value_1: int
        * value_2: str
        * ...

    Interface:
        decode: Extract value from string
        encode: Combine to json string
    """
    @classmethod
    def decode(cls, data: str) -> Type["Mqtt_Message"]:
        """
        Extract all properties from a json string

        * Undefined properties will be set default
        * Raise exception if json string is wrong
        """
        return cls.fromDict(json.loads(data))

    def encode(self) -> str:
        """
        Combine all properties to form a json string message

        If some attributes are not defined, replaced by default values
        """
        return json.dumps(self.items())

class Mqtt_Client:
    """
    Create connection to mqtt broker to publish message to server
    """
    class __MQTT_SUBSCRIPTION:
        def __init__(self, message_type: Mqtt_Message, clbk: Callable, qos: int) -> None:
            self.type = message_type
            self.clbk = clbk
            self.qos = qos
    
    def __init__(self, name: str) -> None:
        self.__client = mqtt.Client(client_id=name)
        self.__client.on_connect = self.__onConnect
        self.__client.on_message = self.__onReceive

        self.__name = name
        self.__subscriptions: Dict[str, Mqtt_Client.__MQTT_SUBSCRIPTION] = {}
        self.__clbk = Callback_Handle(MQTT_CALLBACK_TYPE)
        self.__done = True
        self.__logger = Logger("MQTT")
    
    def getName(self) -> str:
        """
        Return mqtt id
        """
        return self.__name
    
    def connected(self) -> bool:
        """
        Return True if mqtt connection is on
        """
        return self.__client.is_connected()

    def __del__(self):
        self.disconnect()

    def addCallback(self, typ: str, func: Callable):
        """
        typ: type of callback (MQTT_CALLBACK_TYPE)
        func: callback called after function

        * CONNECT: func(name) - Call on connected to mqtt broker
        * RECEIVE: func(name, topic, message) - Call on receive message from any topic
        * DISCONNECT: func(name) - Call on disconnected to mqtt broker
            - name: (str) mqtt client name
            - topic: (str) mqtt topic
            - message: (str) raw payload
        """
        self.__clbk.add(typ, func)
    
    def connect(self, **kwargs) -> bool:
        """
        Kwargs:
            host: str
            port: int = 1883
            user: str = None
            password: int = None
        """
        self.disconnect()
        if "user" in kwargs and "password" in kwargs:
            self.__client.username_pw_set(kwargs["user"], kwargs["password"])
        
        connect_data = {}
        for key in kwargs:
            if key in ["host", "port"]:
                connect_data[key] = kwargs[key]
        try:
            res = self.__client.connect(**connect_data)
            if res == mqtt.MQTT_ERR_SUCCESS:
                self.__client.loop_start()
                return True
            else:
                raise Exception(res)
        except Exception as e:
            self.__logger.error(
                "Error connecting to mqtt broker"
                f"({kwargs}): {e}"
            )
        return False

    def waitConnection(self, debug_text: str = "") -> None:
        """
        Block until connection is setup
        """
        while not self.connected():
            if debug_text != "":
                self.__logger.debug(debug_text)
            sleep(0.5)

    def disconnect(self) -> None:
        """
        Disconnection from broker, remove client and subscriptions.
        Must call to delete object
        """
        if self.__client != None:
            self.__client.loop_stop()
            self.__client.disconnect()
            self.__clbk.call(MQTT_CALLBACK_TYPE.DISCONNECT, self.__name)
    
    def publish(self, topic: str, message: Mqtt_Message, qos: int = 0, timeout: float = None) -> bool:
        """
        qos: mqtt qos
            - 0: atmost 1
            - 1: atleast 1
            - 2: only 1
        timeout: wait for publish timeout (None = forever)

        Return: True if success
        """
        if not self.connected():
            return False
        
        try:
            res = self.__client.publish(topic, message.encode(), qos=qos)
            res.wait_for_publish(timeout)
            if res.rc == mqtt.MQTT_ERR_SUCCESS:
                return True
            else:
                raise Exception(f"Response code - {res.rc}")
        except Exception as e:
            self.__logger.error(f"Error publish to topic {topic}: {e}")
        return False
    
    def subscribe(self, topic: str, message_type: Mqtt_Message, qos: int = 0, clbk: Callable = None) -> bool:
        """
        Subscibe to a topic in mqtt. Auto resubscribe when reconnected.

        Args:
        - topic: (str) mqtt topic
        - qos: (int) mqtt qos
            - 0: atmost 1
            - 1: atleast 1
            - 2: only 1
        - clbk: clbk(name: str, topic: str, message: Mqtt_Message) callback when received this topic only
            - name - mqtt client name
            - topic - this topic
            - message - payload
        
        Return: True if success
        """
        self.__subscriptions[topic] = Mqtt_Client.__MQTT_SUBSCRIPTION(message_type, clbk, qos)
        
        if not self.connected():
            return False
        try:
            self.__client.subscribe(topic=topic, qos=qos)
            return True
        except Exception as e:
            self.__logger.error(f"Error subscribe to topic {topic}: {e}")
            return False

    def unsubscribe(self, topic: str):
        """
        Unsubscribe unnecessary topic
        """
        if self.__client:
            self.__client.unsubscribe(topic)
        if topic in self.__subscriptions:
            self.__subscriptions.pop(topic)
    
    # THREAD, CALLBACK
    def __onConnect(self, client: mqtt.Client, userdata, flags, rc):
        self.__clbk.call(MQTT_CALLBACK_TYPE.CONNECT, self.__name)
        self.__resubscribe()
    
    def __onReceive(self, client: mqtt.Client, userdata, msg: mqtt.MQTTMessage):
        topic = msg.topic
        raw_msg = msg.payload.decode()
        message = self.__subscriptions[topic].type.decode(raw_msg)

        self.__clbk.call(MQTT_CALLBACK_TYPE.RECEIVE, self.__name, topic, raw_msg)
        if topic in self.__subscriptions and self.__subscriptions[topic].clbk != None:
            self.__subscriptions[topic].clbk(self.__name, topic, message)
    
    def __resubscribe(self):
        """
        Trigger when reconnected
        """
        for topic in self.__subscriptions:
            self.__client.subscribe(topic=topic, qos=self.__subscriptions[topic].qos)

    @Worker.employ
    def serve(self, **kwargs):
        """
        Auto reconnect to broker in another thread

        Kwargs:
            host: str
            port: int = 1883
            user: str = None
            password: int = None
        """
        self.__done = False
        while not self.__done:
            if not self.connected():
                self.connect(**kwargs)
            sleep(3)
    
    def stopServe(self):
        """
        Stop serve connection to broker
        """
        self.__done = True