from rostek_utils.utils.pattern import Declare_Class, Singleton
from rostek_utils.utils.logger import Logger
from rostek_utils.utils.thread import Worker
import redis
import redis.client
import json, traceback
from time import sleep
from typing import Callable, Dict, List, Type

class Signal_Handle(metaclass=Singleton):
    """
    Handle callback function through signal (Singleton).
    - Callback will be subscribed to channel
    - When emit signal, callback will be called

    Setup:
    - addChannel: create new signal channel
    
    Interface:
    - subscribe: register a callback to a channel
    - emit: call all callback on channel

    NOTE: Change these lines in redis lib (redis/client.py), at get_message method
    ```py
    if timeout:
        time_spent = time.time() - start_time
        timeout = max(0.0, timeout - time_spent)
    ```
    """
    class Signal:
        model: Type[Declare_Class]
        clbk: List[Callable]

    __redis: redis.Redis
    __conn: redis.client.PubSub
    __signal: Dict[str, Signal]
    __logger = Logger("SIGNAL")

    def __init__(self, redis_host: str = "127.0.0.1", redis_port: int = 6379) -> None:
        self.__conn = None
        self.__signal = {}
        
        self.__redis = redis.Redis(
            redis_host, redis_port,
            0, None,
            decode_responses=True  # Automatically decode responses to Python strings
        )
        self.__handleSignal()
        while self.__conn is None:
            sleep(1)

    def addChannel(self, channel: str, model: Type[Declare_Class]):
        """
        Add channel to handle signal. Need called before emit and subscribe
        """
        self.__conn.subscribe(channel)
        self.__signal[channel] = Signal_Handle.Signal()
        self.__signal[channel].model = model
        self.__signal[channel].clbk = []

    @Worker.employ
    def __handleSignal(self):
        """
        Handle all channedls signal, run in another thread

        signal_data: { [channel]: [payload] }
        """
        self.__conn = self.__redis.pubsub()
        while True:
            data = self.__conn.get_message(True, None)
            if not data:
                continue
            
            message = data['data']
            if not message or type(message) == int:
                continue

            try:
                message = json.loads(message)
                channel = message["channel"]
            except Exception as e:
                self.__logger.error(f"Fail to parse message: {e}")
                continue

            if channel not in self.__signal:
                continue

            try:
                model_type = self.__signal[channel].model
                payload = model_type.decode(message["payload"])
            except Exception as e:
                self.__logger.error(f"Fail to parse payload: {e}")
                continue

            for clbk in self.__signal[channel].clbk:
                try:
                    Worker.employ(clbk)(payload)
                except Exception as e:
                    self.__logger.error(f"Fail to callback: {e}\n{traceback.format_exc()}")
    
    @staticmethod
    def __handleSignalException(func: Callable):
        def inner(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                Signal_Handle.__logger.error(f"Handle signal error: {e}\n{traceback.format_exc()}")
        return inner
    
    @__handleSignalException
    def emit(self, channel: str, payload: Declare_Class):
        """
        Call all functions that subscribe this channel
        """
        self.__redis.publish(
            channel=channel,
            message=json.dumps({
                "channel": channel,
                "payload": payload.encode()
            })
        )
        return True
    
    @__handleSignalException
    def subscribe(self, channel: str, clbk: Callable):
        """
        Subcribe to a channel, will be executed on emit

        Args:
            channel: channel name
            clbk: callback triggered when received emission

        clbk(payload: Declare_Class)

        Return: False if channel not added
        """
        if channel not in self.__signal:
            return False
        
        self.__signal[channel].clbk.append(clbk)
        return True