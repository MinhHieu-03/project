from ..utils.logger import Logger
from ..utils.pattern import Define_Class

from typing import Callable, Dict

class CALLBACK_TYPE(Define_Class):
    """
    Define all callback types
    """

class Callback_Handle:
    """
    Handle callback for communication package
    """
    def __init__(self, types: CALLBACK_TYPE) -> None:
        self.__clbk: Dict[str, list] = {}
        for type in types.values():
            self.__clbk[type] = []
    
    def add(self, typ: str, func: Callable):
        """
        Add callback

        typ: type of function (CALLBACK_TYPE)
        func: callback called after action
        """
        self.__clbk[typ].append(func)
    
    def __getitem__(self, func: str):
        return self.__clbk[func]
    
    def call(self, func: str, *args, **kwargs):
        """
        Call callback

        func: type of function (CALLBACK_TYPE)
        """
        try:
            for clbk in self.__clbk[func]:
                clbk(*args, **kwargs)
        except Exception as e:
            Logger("CALLBACK").error(f"Call on {func} error ({e})")