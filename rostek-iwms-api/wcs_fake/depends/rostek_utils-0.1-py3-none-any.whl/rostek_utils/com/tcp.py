from .callback import Callback_Handle, CALLBACK_TYPE
from ..utils.logger import Logger
from ..utils.thread import Worker

import socket
from time import sleep
from typing import Callable, List

class TCP_CALLBACK_TYPE (CALLBACK_TYPE):
    CONNECT = "connect"
    ACCEPT = "accept"
    RECEIVE = "receive"
    DISCONNECT = "disconnect"

class Tcp_Client:
    """
    Handle data from and to other devices through TCP
    """
    def __init__(self, ip: str, port: int) -> None:
        self.__conn: socket.socket = None

        self.__host = (ip, port)
        self.__logger = Logger("TCP_CLIENT")
        self.__clbk = Callback_Handle(TCP_CALLBACK_TYPE)

        self.connected = False
        self.auto_read = Worker.employ(self.handle)

    def __del__(self):
        self.disconnect()
    
    # HELPER
    def getAddress(self) -> tuple:
        """
        Get client address

        Return (ip: str, port: int)
        """
        if self.connected:
            return self.__conn.getsockname()
    
    def getPeerAddress(self) -> tuple:
        """
        Get peer address

        Return (ip: str, port: int)
        """
        if self.connected:
            return self.__conn.getpeername()

    def addCallback(self, typ: str, func: Callable):
        """
        typ: type of function (TCP_CALLBACK_TYPE)
        func: callback called after function

        CONNECT: func() - Call on accepted by server
        ACCEPT: func(self: Tcp_Client) - Call on accept new connection manually
        RECEIVE: func(self: Tcp_Client, msg: str) - Call on receive message from server
        DISCONNECT: func() - Call on disconnect to server
        """
        self.__clbk.add(typ, func)

    # CONNECTION
    def connect(self):
        """
        Create socket connection and try to connect to host
        
        Check connected after call
        """
        self.disconnect()
        self.__conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.__conn.settimeout(0.5)
        try:
            self.__conn.connect(self.__host)
            self.connected = True
            self.__clbk.call(TCP_CALLBACK_TYPE.CONNECT)
        except Exception as e:
            self.__logger.error(f"Fail to connect to server (Error: {e})")

    def accept(self, conn: socket.socket):
        """
        Manually assign socket connection
        """
        self.__conn = conn
        self.__conn.settimeout(0.5)
        self.connected = True
        self.__clbk.call(TCP_CALLBACK_TYPE.ACCEPT, self)

    def disconnect(self):
        """
        Disconnect from socket connection
        """
        self.connected = False
        if self.__conn:
            self.__conn.close()
            self.__conn = None
            self.__clbk.call(TCP_CALLBACK_TYPE.DISCONNECT)
    
    # HANDLE
    def handle(self):
        """
        Handle data received from connection. Used to check connection as well

        Format: msg + \\r\\n\\r\\n
        """
        data_buf = ""
        while True:
            try:
                recv = self.__conn.recv(1024)
                if not recv:
                    break
            except ConnectionResetError:
                break
            except socket.timeout:
                continue
            except Exception as e:
                self.__logger.error(f"Error receive tcp: {e}")
                break

            data_buf += recv.decode()
            while "\r\n\r\n" in data_buf:
                id = data_buf.index("\r\n\r\n")
                msg = data_buf[:id]
                data_buf = data_buf[id+4:]
                self.__clbk.call(TCP_CALLBACK_TYPE.RECEIVE, self, msg)

        self.__logger.error(f"Connection closed!")
        self.disconnect()

    def send(self, cmd: str) -> bool:
        """
        Send command to tcp server

        Format: cmd + \\r\\n\\r\\n

        Return True if success
        """
        if not self.connected:
            return False
        
        cmd += "\r\n\r\n"
        self.__conn.sendall(cmd.encode('UTF-8'))
        return True

    @Worker.employ
    def listen(self):
        """
        Auto reconnect to server and read forever (async)
        """
        while True:
            while not self.connected:
                self.connect()
                sleep(1)
            
            self.handle()

class Tcp_Server:
    """
    Handle TCP clients
    """
    def __init__(self, ip: str, port: int) -> None:
        """
        ip: server ip address
        port: server port
        """
        self.connected = False

        self.__server: socket.socket = None
        self.__clients: List[Tcp_Client] = []
        self.__host = (ip, port)
        self.__logger = Logger("TCP_SERVER")
        self.__clbk = Callback_Handle(TCP_CALLBACK_TYPE)
        self.__done = False

    def __del__(self):
        self.disconnect()
    
    # HELPER
    def addCallback(self, typ: str, func: Callable):
        """
        typ: type of function (TCP_CALLBACK_TYPE)
        func: callback called after action

        * CONNECT: func()
        * ACCEPT: func(client: Tcp_Client)
        * RECEIVE: func(client: Tcp_Client, msg: str)
        * DISCONNECT: func()
        """
        self.__clbk.add(typ, func)

    # CONNECTION
    def connect(self):
        """
        Open server and listening to clients
        """
        self.disconnect()
        self.__done = False

        self.__server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.__server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.__server.settimeout(0.5)
        try:
            self.__server.bind(self.__host)
            self.__server.listen(2)
            self.connected = True
            self.__clbk.call(TCP_CALLBACK_TYPE.CONNECT)
        except Exception as e:
            self.__logger.error(f"Fail to connect to client (Error: {e})")

    def disconnect(self):
        """
        Disconnect to any clients and close server
        """
        self.__done = True
        for client in self.__clients:
            client.disconnect()
        self.__clients.clear()
        if self.__server:
            self.__server.close()
            self.__server = None
        self.connected = False
        self.__clbk.call(TCP_CALLBACK_TYPE.DISCONNECT)

    # HANDLE
    @Worker.employ
    def listen(self):
        """
        Auto reconnect and wait for clients forever
        """
        self.__autoRemove()
        while not self.__done:
            while not self.__done and not self.connected:
                self.connect()
                sleep(1)
            
            while not self.__done:
                try:
                    conn, address = self.__server.accept()
                    self.__newClient(conn, address)
                    self.__logger.info(f"Client {address} connected.")
                except socket.timeout:
                    sleep(2)
                    continue
                except Exception as e:
                    self.__logger.error(f"Error accept tcp client: {e}")
                    break

    def __newClient(self, conn: socket.socket, address: tuple):
        """
        Create new client after accepted

        conn: connection to client
        address: client address (ip, port)
        """
        new_client = Tcp_Client(*address)
        new_client.accept(conn)
        for func in self.__clbk[TCP_CALLBACK_TYPE.RECEIVE]:
            new_client.addCallback(TCP_CALLBACK_TYPE.RECEIVE, func)
        new_client.auto_read()
        self.__clients.append(new_client)
        self.__clbk.call(TCP_CALLBACK_TYPE.ACCEPT, new_client)
    
    @Worker.employ
    def __autoRemove(self):
        """
        Remove disconnected clients
        """
        while not self.__done:
            for client in self.__clients:
                if not client.connected:
                    self.__clients.remove(client)
                    break
            sleep(1)