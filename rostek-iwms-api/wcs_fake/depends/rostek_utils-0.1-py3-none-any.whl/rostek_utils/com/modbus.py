from ..utils.thread import Worker
from ..utils.logger import Logger
from .callback import Callback_Handle, CALLBACK_TYPE

from pymodbus.server import StartTcpServer, StartSerialServer
from pymodbus.client import ModbusSerialClient, ModbusTcpClient
from pymodbus.datastore import ModbusSequentialDataBlock, ModbusSlaveContext, ModbusServerContext
from time import sleep
from typing import Callable

class MODBUS_MASTER_CALLBACK_TYPE (CALLBACK_TYPE):
    CONNECT = "connect"
    RECEIVE = "receive"
    DISCONNECT = "disconnect"

class MODBUS_SLAVE_CALLBACK_TYPE (CALLBACK_TYPE):
    READ = "read"
    WRITE = "write"

class Modbus_Address_Abs:
    '''
    Declare this class for modbus server and/or client
        number_coils: number of coils
        number_registers: number of registers
    Holding registers (or Input registers):
        REG_<name> = <address>
    Coils (or Discrete inputs):
        COIL_<name> = <address>
    '''
    def __init__(self, number_coils: int, number_registers: int) -> None:
        self.number_coils = number_coils
        self.number_registers = number_registers

class Modbus_Function:
    READ_COILS  = 1
    READ_INPUTS = 2
    READ_H_REGS = 3
    READ_I_REGS = 4
    WRITE_COIL  = 5
    WRITE_REG   = 6
    WRITE_COILS = 15
    WRITE_REGS  = 16

class CustomModbusSlaveContext(ModbusSlaveContext):
    def __init__(self, *_args, **kwargs):
        """
        Abstract layer of modbus slave to handle callback
        """
        super().__init__(*_args, **kwargs)
        self.__clbk = Callback_Handle(MODBUS_SLAVE_CALLBACK_TYPE)

    def addCallback(self, typ: str, func: Callable):
        """
        typ: type of callback (MODBUS_SLAVE_CALLBACK_TYPE)
        func: callback called after function

        * READ: func(slave_id, is_coil, address, values) - Call on receive get command
        * WRITE: func(slave_id, is_coil, address, values) - Call on receive set command
            - slave_id: (int) modbus server id
            - is_coil: (bool) True if command handle coil (else it will be 16 bit register)
            - address: (int) modbus coil/register address
            - values: (list(int)) read/write values
        """
        self.__clbk.add(typ, func)

    def getValues(self, fc_as_hex: int, address: int, count: int = 1, internal: bool = False, id: int = 0) -> list:
        result = super().getValues(fc_as_hex, address, count)
        if not internal:
            self.__clbk.call(MODBUS_SLAVE_CALLBACK_TYPE.READ,
                id,
                True if fc_as_hex in [Modbus_Function.READ_COILS, Modbus_Function.READ_INPUTS] else False,
                address,
                result
            )
        return result

    def setValues(self, fc_as_hex: int, address: int, values: list, internal: bool = False, id: int = 0):
        super().setValues(fc_as_hex, address, values)
        if not internal:
            self.__clbk.call(MODBUS_SLAVE_CALLBACK_TYPE.WRITE,
                id,
                True if fc_as_hex in [Modbus_Function.WRITE_COIL, Modbus_Function.WRITE_COILS] else False,
                address,
                values
            )

class Modbus_Server:
    def __init__(self, address_data: Modbus_Address_Abs, id: int = 1) -> None:
        """
        address_data: Modbus_Address instance
        setCallback: set register callback (is coil, address, number of regs, values)
        getCallback: get reigster callback (is coil, address, new values)
        """
        self.address = address_data
        self.__id = id
        
        holding_block = ModbusSequentialDataBlock(0, [0] * (self.address.number_registers + 1))
        coil_block = ModbusSequentialDataBlock(0, [False] * (self.address.number_coils + 1))
        self.__store = {
            self.__id: CustomModbusSlaveContext(
                co=coil_block, di=coil_block, hr=holding_block, ir=holding_block
            )
        }

    def addCallback(self, func: str, clbk: Callable):
        """
        func: type of callback (MODBUS_SLAVE_CALLBACK_TYPE)
        clbk: callback called after function

        READ: clbk(slave_id, is_coil, address, values) - Call on receive get command
        WRITE: clbk(slave_id, is_coil, address, values) - Call on receive set command
            slave_id: (int) modbus server id
            is_coil: (bool) True if command handle coil (else it will be 16 bit register)
            address: (int) modbus coil/register address
            values: (list(int)) read/write values
        """
        self.__store[self.__id].addCallback(func, clbk)

    @Worker.employ
    def start(self, **kwargs):
        """
        Start server in another thread
        
        Kwargs:
            type: "RTU"
                port: str
                baud: int
                data: 7 | 8
                stop: 1 | 2
                parity: "N" - None | "E" - Even | "O" - Odd
            type: "TCP"
                host: str
                port: int
        """
        if kwargs["type"] == "RTU":
            StartSerialServer(
                context = ModbusServerContext(slaves=self.__store, single=False),
                port = kwargs["port"],
                stopbits = kwargs["stop"],
                bytesize = kwargs["data"],
                parity = kwargs["parity"],
                baudrate = kwargs["baud"]
            )
        elif kwargs["type"] == "TCP":
            StartTcpServer(
                context = ModbusServerContext(slaves=self.__store, single=False),
                address = (kwargs["host"], kwargs["port"])
            )

    def read(self, start: int, count: int = 1, is_coil: bool = True) -> list:
        """
        start: start address
        count: number of addresses
        is_coil: True if read coils

        return: list of values
        """
        return self.__store[self.__id].getValues(
            Modbus_Function.READ_COILS if is_coil else Modbus_Function.READ_H_REGS,
            start, count, True, self.__id
        )
    
    def write(self, start: int, values: list, is_coil: bool = True):
        """
        start: start address
        values: values to write
        is_coil: True if read coils

        return: True if success
        """
        self.__store[self.__id].setValues(
            Modbus_Function.WRITE_COILS if is_coil else Modbus_Function.WRITE_REGS,
            start, values, True, self.__id
        )
    
class Modbus_Client:
    """
    Modbus master common methods
    """
    def __init__(self) -> None:
        self.__done = True
        self.__mb = None
        self.__clbk = Callback_Handle(MODBUS_MASTER_CALLBACK_TYPE)
        self.connected = False
        self.__logger = Logger("MODBUS_CLIENT")

    def addCallback(self, typ: str, func: Callable):
        """
        typ: type of callback (MODBUS_MASTER_CALLBACK_TYPE)
        func: callback called after function

        CONNECT: clbk() - Call on connect to slave
        DISCONNECT: clbk() - Call on disconnect from slave
        RECEIVE: clbk(slave_id, is_coil, address, values) - Call on receive from read command
            slave_id: (int) modbus server id
            is_coil: (bool) True if command handle coil (else it will be 16 bit register)
            address: (int) modbus coil/register address
            values: (list(int)) read/write values
        """
        self.__clbk.add(typ, func)
        
    def connect(self, **kwargs):
        """
        Kwargs:
            type: "RTU"
                port: str
                baud: int
                data: 7 | 8
                stop: 1 | 2
                parity: "N" - None | "E" - Even | "O" - Odd
            type: "TCP"
                host: str
                port: int
            timeout: float (second)
        """
        self.disconnect()
        if kwargs["type"] == "RTU":
            mb = ModbusSerialClient(
                port = kwargs["port"],
                stopbits = kwargs["stop"],
                bytesize = kwargs["data"],
                parity = kwargs["parity"],
                baudrate = kwargs["baud"],
                timeout = kwargs["timeout"]
            )
        elif kwargs["type"] == "TCP":
            mb = ModbusTcpClient(
                host = kwargs["host"],
                port = kwargs["port"],
                timeout = kwargs["timeout"]
            )
        if mb.connect():
            self.__mb = mb
            self.connected = True
            self.__clbk.call(MODBUS_MASTER_CALLBACK_TYPE.CONNECT)
            return True
        return False
        
    def disconnect(self):
        if self.__mb:
            self.__mb.close()
            self.__mb = None
            self.__clbk.call(MODBUS_MASTER_CALLBACK_TYPE.DISCONNECT)
        self.connected = False
        
    def read(self, id: int, start: int, count: int, is_coil: bool = True) -> list:
        """
        id: slave id
        start: start address
        count: number of addresses
        is_coil: True if read coils

        return: list of values | None if error/disconnected
        """
        if not self.connected:
            return None
        
        if is_coil:
            try:
                res = self.__mb.read_coils(start, count, id)
                if res.isError():
                    self.__logger.error(f"Read modbus fail: {res}")
                    return
                data = res.bits[:count]
            except Exception as e:
                self.__logger.error(f"Read modbus fail: {e}")
                return
        else:
            try:
                res = self.__mb.read_holding_registers(start, count, id)
                if res.isError():
                    self.__logger.error(f"Read modbus fail: {res}")
                    return
                data = res.registers[:count]
            except Exception as e:
                self.__logger.error(f"Read modbus fail: {e}")
                return
        self.__clbk.call(MODBUS_MASTER_CALLBACK_TYPE.RECEIVE, id, is_coil, start, data)
        return data

    def write(self, id: int, start: int, values: list, is_coil: bool = True) -> bool:
        """
        id: slave id
        start: start address
        values: values to write
        is_coil: True if read coils

        return: True if success
        """
        if not self.connected:
            return None
        
        if is_coil:
            try:
                return not self.__mb.write_coils(start, values, id).isError()
            except Exception as e:
                self.__logger.error(f"Write modbus fail: {e}")
        else:
            try:
                return not self.__mb.write_registers(start, values, id).isError()
            except Exception as e:
                self.__logger.error(f"Write modbus fail: {e}")
    
    @Worker.employ 
    def serve(self, **kwargs):
        """
        Auto reconnect modbus connection
        
        Kwargs:
            type: "RTU"
                port: str
                baud: int
                data: 7 | 8
                stop: 1 | 2
                parity: "N" - None | "E" - Even | "O" - Odd
            type: "TCP"
                host: str
                port: int
            timeout: float (second)
        """
        self.__done = False
        while not self.__done:
            if not self.connected:
                self.__logger.warn(f"Try to connect modbus: {kwargs}")
                self.connect(**kwargs)
            sleep(1)
    
    def stopServe(self):
        """
        Stop serve modbus connection
        """
        self.__done = True