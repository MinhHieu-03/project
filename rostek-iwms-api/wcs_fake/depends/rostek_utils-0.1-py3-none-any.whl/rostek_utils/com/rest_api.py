from ..utils.pattern import Singleton
from ..utils.thread import Worker
from ..utils.logger import Logger

from pydantic import BaseModel as Request_Model
from fastapi import FastAPI
import uvicorn
import requests
from time import sleep

class HTTP_RESPONSE_CODE:
    OK = [200, 201]
    BAD_REQUEST = [400, 404]
    SERVER_ERROR = [500]

class RestApi(metaclass=Singleton):
    server = FastAPI()
    client = requests
    
    @staticmethod
    @Worker.employ
    def serve(host: str = "127.0.0.1", port: int = 5000):
        """
        Run in another thread
        """
        RestApi.run(host, port)
    
    @staticmethod
    def run(host: str = "127.0.0.1", port: int = 5000):
        """
        Handle api server forever
        """
        logger = Logger("REST_API")
        while True:
            try:
                uvicorn.run(RestApi.server, host=host, port=port)
            except KeyboardInterrupt:
                pass
            logger.warning("Pause 3s. Ctrl-C to exit!")
            
            try:
                sleep(3)
            except KeyboardInterrupt:
                break
        logger.warning("Exit!")